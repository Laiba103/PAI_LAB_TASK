# ✨ AI-Based Context-Aware Message Tone Converter

An intelligent web application built with **Flask** and **Natural Language Processing (NLP)** that transforms the tone of your messages into various styles, including Formal, Polite, Professional, and Friendly.

## 🚀 Overview

Effective communication is about more than just words; it’s about how those words are delivered. This project provides a context-aware system that analyzes user input and maps it to a desired emotional tone using machine learning techniques. By utilizing TF-IDF vectorization and Cosine Similarity, the application suggests the most appropriate phrasing for any given scenario.

## 🛠️ Tech Stack

* **Backend:** Flask (Python)
* **Machine Learning:** Scikit-learn (TF-IDF Vectorization, Cosine Similarity)
* **Data Handling:** Pandas, Pickle
* **Frontend:** HTML5, CSS3 (Responsive Design)

## 📂 Project Structure

```text
final project/
├── app.py              # Main Flask application logic
├── tone_dataset.csv    # Dataset containing tone-mapped message pairs
├── vectorizer.pkl      # Pre-trained TF-IDF Vectorizer
├── data.pkl            # Processed DataFrame for rapid similarity matching
├── requirements.txt    # Project dependencies
├── README.md           # Project documentation
├── static/
│   └── style.css       # Custom UI styling and layouts
└── templates/
    └── index.html      # Main web interface (Jinja2 Template)
