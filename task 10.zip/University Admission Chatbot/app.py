from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Simple chatbot logic
def get_bot_response(user_message):
    user_message = user_message.lower()

    if "admission" in user_message:
        return "Admissions are open! You need minimum 60% marks."
    
    elif "deadline" in user_message:
        return "The last date to apply is 30th August."
    
    elif "programs" in user_message:
        return "We offer BSCS, BBA, and Engineering programs."
    
    elif "fee" in user_message:
        return "The average fee is 50,000 PKR per semester."
    
    else:
        return "Sorry, I didn't understand. Please ask about admission, deadline, or programs."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot():
    user_message = request.form["msg"]
    response = get_bot_response(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)