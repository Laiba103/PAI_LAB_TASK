from flask import Flask, render_template, request
import os
import pickle
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# -------------------------------
# Load files safely
# -------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

vectorizer = pickle.load(open(os.path.join(BASE_DIR, "vectorizer.pkl"), "rb"))
df = pickle.load(open(os.path.join(BASE_DIR, "data.pkl"), "rb"))

# Rebuild matrix (IMPORTANT)
X = vectorizer.transform(df["combined"])

# -------------------------------
# AI Prediction Function
# -------------------------------
def predict_tone(user_text, tone):
    user_input = user_text + " " + tone
    user_vec = vectorizer.transform([user_input])

    similarity = cosine_similarity(user_vec, X)
    index = similarity.argmax()

    return df.iloc[index]["output_text"]

# -------------------------------
# Route
# -------------------------------
@app.route("/", methods=["GET", "POST"])
def home():
    output = ""

    if request.method == "POST":
        text = request.form["text"]
        tone = request.form["tone"]

        output = predict_tone(text, tone)

    return render_template("index.html", output=output)

# -------------------------------
# Run App
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)