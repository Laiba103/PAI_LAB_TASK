# ✨ AI-Based Context-Aware Message Tone Converter

An intelligent web application built with **Flask** and **Natural Language Processing (NLP)** that transforms the tone of your messages into various styles like Formal, Polite, Professional, and Flirty.

## 🚀 Overview
Communication is key, but the *way* you say something matters just as much as *what* you say. This project provides a context-aware system that analyzes your input and maps it to a desired tone using machine learning techniques.

## 🛠️ Tech Stack
- **Backend:** Flask (Python)
- **Machine Learning:** Scikit-learn (TF-IDF Vectorization, Cosine Similarity)
- **Data Handling:** Pandas, Pickle
- **Frontend:** HTML5, CSS3 (with responsive design)

## 📂 Project Structure
```text
final project/
├── app.py              # Main Flask application
├── tone_dataset.csv    # Dataset containing message mappings
├── vectorizer.pkl      # Saved TF-IDF Vectorizer model
├── data.pkl           # Processed dataframe for similarity matching
├── requirements.txt    # List of dependencies
├── README.md           # Project documentation
├── static/
│   └── style.css       # Custom UI styling
└── templates/
    └── index.html      # Web interface