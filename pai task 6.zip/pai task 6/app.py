from flask import Flask, render_template, Response
import cv2
import numpy as np
import random

app = Flask(__name__)
camera = cv2.VideoCapture(0)  # still using webcam for background

def generate_frames():
    while True:
        success, frame = camera.read()
        if not success:
            break

        # Resize frame for consistent display
        frame = cv2.resize(frame, (640, 480))

        # Simulated moving objects (demo only)
        count = 5  # number of objects to show
        for i in range(count):
            # random positions
            x, y = random.randint(50, 550), random.randint(50, 400)
            cv2.rectangle(frame, (x, y), (x+50, y+50), (0, 255, 0), 2)

        # Display object count
        cv2.putText(frame, f'Objects: {count}', (10,50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2)

        # Convert frame to JPEG
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video')
def video():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(debug=True)