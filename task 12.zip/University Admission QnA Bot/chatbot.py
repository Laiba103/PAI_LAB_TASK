from dataset import qa_data
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from dataset import qa_data

# 1. Load model
model = SentenceTransformer('all-MiniLM-L6-v2')

# 2. Split data
questions = [item["question"] for item in qa_data]
answers = [item["answer"] for item in qa_data]

# 3. Create embeddings
question_embeddings = model.encode(questions)

# 4. Create FAISS index
dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(question_embeddings))

# 5. Search function
def get_answer(user_query):
    query_embedding = model.encode([user_query])
    distances, indices = index.search(np.array(query_embedding), k=1)

    best_match = indices[0][0]
    return answers[best_match]