from flask import Flask, render_template, request
from chatbot import get_answer

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chat():
    user_msg = request.form["msg"]
    response = get_answer(user_msg)
    return response

if __name__ == "__main__":
    app.run(debug=True)