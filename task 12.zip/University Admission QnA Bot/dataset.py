qa_data = [
    {"question": "What are admission requirements?",
     "answer": "You need FSc/A-levels with minimum 50% marks."}
]