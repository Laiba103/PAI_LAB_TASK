from flask import Flask, render_template_string
import requests

app = Flask(__name__)

@app.route('/')
def home():
    url = "https://official-joke-api.appspot.com/random_joke"
    response = requests.get(url)
    data = response.json()

    setup = data["setup"]
    punchline = data["punchline"]

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Random Joke</title>
    </head>
    <body style="text-align:center; margin-top:100px; font-family:Arial;">
        <h1>😂 Random Joke</h1>
        <h3>{setup}</h3>
        <p><b>{punchline}</b></p>
        <br>
        <button onclick="window.location.reload()">Get Another Joke</button>
    </body>
    </html>
    """

    return render_template_string(html)


if __name__ == '__main__':
    app.run(debug=True)